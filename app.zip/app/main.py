from fastapi import FastAPI
from pydantic import BaseModel

from app.smartlogix_agent import smartlogix_agent, smartlogix_agent_details


app = FastAPI(
    title="SmartLogix AI API",
    description="AI-powered logistics intelligence API",
    version="1.0.0"
)


class QuestionRequest(BaseModel):
    question: str


@app.get("/")
def root():
    return {
        "message": "SmartLogix AI API is running"
    }


@app.post("/ask")
def ask_question(request: QuestionRequest):
    return {
        "question": request.question,
        "message": "SmartLogix AI received your question successfully."
    }


@app.post("/ask-agent")
def ask_agent(request: QuestionRequest):

    result = smartlogix_agent_details(request.question)

    return result